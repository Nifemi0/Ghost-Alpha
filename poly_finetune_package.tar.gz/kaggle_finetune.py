
import torch
import torch.nn as nn
import pandas as pd
import numpy as np
import gc
import os

from sentence_transformers import SentenceTransformer
from sklearn.model_selection import train_test_split

# --- Configuration ---
# Assumes you've uploaded your model, columns, and data to a Kaggle dataset named "poly-finetune-assets"
KAGGLE_INPUT_DIR = "/kaggle/input/poly-finetune-assets"
KAGGLE_OUTPUT_DIR = "/kaggle/working/"

# --- Paths ---
# Path to the pre-trained model you uploaded
PRETRAINED_MODEL_PATH = os.path.join(KAGGLE_INPUT_DIR, "brain_v3.pt") 
# Path to the column definition file
COLUMN_PATH = os.path.join(KAGGLE_INPUT_DIR, "columns_v3.pkl")
# Path to your new dataset for fine-tuning
FINETUNE_DATA_PATH = os.path.join(KAGGLE_INPUT_DIR, "your_finetuning_data.csv")
# Path to save the new, fine-tuned model
FINETUNED_MODEL_PATH = os.path.join(KAGGLE_OUTPUT_DIR, "brain_v3_finetuned.pt")

# --- Device ---
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {device}")

# --- Feature Engineering ---
# --- Feature Engineering ---
def custom_engineer_features():
    db_path = os.path.join(KAGGLE_INPUT_DIR, "poly.db")
    if not os.path.exists(db_path):
        print(f"Database not found at {db_path}")
        return None, None
        
    engine = create_engine(f"sqlite:///{db_path}")
    print("Loading resolved events from database...")
    query = "SELECT * FROM events WHERE outcome IS NOT NULL"
    df = pd.read_sql(query, engine, parse_dates=['start_time', 'end_time'])

    if df.empty:
        print("No resolved events found.")
        return None, None

    print(f"Engineering features for {len(df)} samples...")
    df['time_to_event_days'] = (df['end_time'] - df['start_time']).dt.days
    
    print("Generating text embeddings (Batch Mode)...")
    st_model = SentenceTransformer('all-MiniLM-L6-v2')
    
    summaries = df['news_summary'].fillna('').tolist()
    all_embeddings = []
    batch_size = 1000
    
    for i in range(0, len(summaries), batch_size):
        batch = summaries[i:i + batch_size]
        batch_emb = st_model.encode(batch, show_progress_bar=False)
        all_embeddings.append(batch_emb)
        gc.collect()
    
    embeddings = np.vstack(all_embeddings)
    embedding_df = pd.DataFrame(embeddings, index=df.index, columns=[f'emb_{i}' for i in range(embeddings.shape[1])])
    
    category_dummies = pd.get_dummies(df['category'], prefix='cat')
    numerical_features = df[['initial_price', 'volume', 'time_to_event_days']].fillna(0)
    
    features = pd.concat([numerical_features, category_dummies, embedding_df], axis=1)
    
    # Load the original columns to ensure consistency
    column_path = os.path.join(KAGGLE_INPUT_DIR, "columns_v3.pkl")
    print(f"Loading column definitions from {column_path}")
    model_columns = joblib.load(column_path)
    
    # Align columns with the original model, filling missing ones with 0
    features = features.reindex(columns=model_columns, fill_value=0)
    
    # Ensure float32
    features = features.apply(pd.to_numeric, errors='coerce').fillna(0).astype('float32')
    
    target = df['outcome'].astype(int)
    return features, target
    
    # --- Initialize and Load Pre-trained Model ---
    input_dim = len(features.columns)
    model = NeuralPredictor(input_dim).to(device)

    print(f"Loading pre-trained weights from {PRETRAINED_MODEL_PATH}...")
    try:
        model.load_state_dict(torch.load(PRETRAINED_MODEL_PATH, map_location=device))
        print("Model weights loaded successfully.")
    except Exception as e:
        print(f"Error loading model weights: {e}")
        print("Continuing with a newly initialized model.")

    # --- Data Splitting ---
    X_train_pd, X_test_pd, y_train_pd, y_test_pd = train_test_split(
        features, target, test_size=0.2, random_state=42, stratify=target
    )
    
    X_train = torch.FloatTensor(X_train_pd.values).to(device)
    y_train = torch.FloatTensor(y_train_pd.values).view(-1, 1).to(device)
    
    del X_train_pd, y_train_pd, features, target # Clear RAM
    gc.collect()

    # --- Fine-tuning ---
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-4) # Use a lower learning rate for fine-tuning
    criterion = nn.BCELoss()
    
    print("Starting Fine-Tuning...")
    for epoch in range(10): # Fewer epochs for fine-tuning
        model.train()
        optimizer.zero_grad()
        outputs = model(X_train)
        loss = criterion(outputs, y_train)
        loss.backward()
        optimizer.step()
        
        if (epoch+1) % 2 == 0: 
            print(f"Epoch {epoch+1} | Loss: {loss.item():.4f}")

    # --- Save the Fine-Tuned Model ---
    os.makedirs(KAGGLE_OUTPUT_DIR, exist_ok=True)
    torch.save(model.state_dict(), FINETUNED_MODEL_PATH)
    print(f"Fine-tuned model saved to {FINETUNED_MODEL_PATH}")

if __name__ == "__main__":
    fine_tune()
